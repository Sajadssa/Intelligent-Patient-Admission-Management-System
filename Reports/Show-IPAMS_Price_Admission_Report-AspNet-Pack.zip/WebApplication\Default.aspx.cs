using Stimulsoft.Report;
using Stimulsoft.Report.Dictionary;
using Stimulsoft.Report.Web;
using System;
using System.Data;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication
{
	public partial class _Default : Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		protected void StiWebViewer1_GetReport(object sender, StiReportDataEventArgs e)
		{
			var report = StiReport.CreateNewReport();
			var path = Server.MapPath("Reports/IPAMS_Price_Admission_Report.mrt");
			report.Load(path);

			e.Report = report;
		}
	}
}